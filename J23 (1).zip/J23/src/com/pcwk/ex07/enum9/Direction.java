package com.pcwk.ex07.enum9;

public enum Direction {
  EAST,SOUTH,WEST,NORTH
}