package com.pcwk.cmn;

import org.apache.log4j.Logger;

public interface LoggerManager {
  //LOG 
  public final static Logger LOG = Logger.getLogger(LoggerManager.class);
}
       